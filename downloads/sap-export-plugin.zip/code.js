figma.showUI(__html__, { width: 320, height: 460, title: 'SAP Design Portal Illustration Exporter' });

const EXPORTABLE = new Set(['FRAME', 'COMPONENT', 'INSTANCE']);

function getSelectionInfo() {
  const selection = figma.currentPage.selection;
  const frames = [];
  let folderName = '';

  for (const node of selection) {
    const children = 'children' in node ? node.children : [];

    // Primary: look for numbered illustration frames inside the selected container
    // Naming convention: NN_ComponentName_SectionName_vXXXX
    const numbered = children.filter(c => EXPORTABLE.has(c.type) && /^\d/.test(c.name));

    if (numbered.length > 0) {
      if (!folderName) folderName = node.name;
      frames.push(...numbered);
    } else if (children.length > 0) {
      // Fallback: take all exportable children if none are numbered
      const exportable = children.filter(c => EXPORTABLE.has(c.type));
      if (exportable.length > 0) {
        if (!folderName) folderName = node.name;
        frames.push(...exportable);
      }
    } else if (EXPORTABLE.has(node.type)) {
      // Individual frame selected directly
      frames.push(node);
    }
  }

  // Sort by name so NN_ prefix ordering is preserved
  frames.sort((a, b) => a.name.localeCompare(b.name));

  // Derive folder name from frame name if container had no name
  // Frame naming convention: NN_ComponentName_SectionName_vXXXX
  if (!folderName && frames.length > 0) {
    const parts = frames[0].name.split('_');
    folderName = parts.length > 1 ? parts[1] : frames[0].name;
  }

  return { frames, folderName };
}

function pushSelectionInfo() {
  const { frames, folderName } = getSelectionInfo();
  figma.ui.postMessage({
    type: 'selection-info',
    count: frames.length,
    names: frames.map(f => f.name),
    folderName
  });
}

// Auto-update UI whenever canvas selection changes
figma.on('selectionchange', pushSelectionInfo);

figma.ui.onmessage = async (msg) => {
  if (msg.type === 'ready') {
    pushSelectionInfo();
  }

  if (msg.type === 'export') {
    const { frames } = getSelectionInfo();

    if (frames.length === 0) {
      figma.ui.postMessage({
        type: 'error',
        message: 'No frames found. Select a section or individual frames first.'
      });
      return;
    }

    for (let i = 0; i < frames.length; i++) {
      try {
        const bytes = await frames[i].exportAsync({
          format: 'PNG',
          constraint: { type: 'SCALE', value: 300 / 72 }
        });

        figma.ui.postMessage({
          type: 'file',
          name: frames[i].name + '.png',
          data: Array.from(bytes),
          current: i + 1,
          total: frames.length
        });
      } catch (e) {
        figma.ui.postMessage({
          type: 'error',
          message: 'Export failed on: ' + frames[i].name
        });
        return;
      }
    }

    figma.ui.postMessage({ type: 'export-complete' });
  }

  if (msg.type === 'close') {
    figma.closePlugin();
  }
};
