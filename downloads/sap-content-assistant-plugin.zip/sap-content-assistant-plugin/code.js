// ── SAP Content Assistant Plugin ──────────────────────────────
figma.showUI(__html__, { width: 420, height: 640, title: 'SAP Content Assistant' });

function parseNodeId(link) {
  if (!link) return null;
  const m = link.match(/node-id=([0-9]+-[0-9]+)/);
  if (m) return m[1].replace('-', ':');
  const bare = link.match(/^([0-9]+:[0-9]+)$/);
  if (bare) return bare[1];
  return null;
}

// ── EXPORT: Read article + scan images → compact JSON ─────────
async function exportData(articleLink, sectionLink) {
  const result = { article: '', images: [], sectionId: '' };

  // Read article text
  if (articleLink) {
    const artId = parseNodeId(articleLink);
    if (artId) {
      const frame = await figma.getNodeByIdAsync(artId);
      if (frame) {
        const blocks = [];
        function walkText(n, sec) {
          if (!n.visible) return;
          if (n.type === 'TEXT' && n.characters?.trim()) {
            blocks.push({ t: n.characters.trim().slice(0, 300), s: sec, y: n.absoluteBoundingBox?.y || 0 });
            return;
          }
          const isSec = n.type === 'FRAME' && n.name && !n.name.startsWith('_');
          n.children?.forEach(c => walkText(c, isSec ? n.name : sec));
        }
        walkText(frame, '');
        blocks.sort((a, b) => a.y - b.y);
        // Compact: join all text, truncate to ~3000 chars
        result.article = blocks.map(b => b.t).join(' ').slice(0, 3000);
      }
    }
  }

  // Scan section images
  if (sectionLink) {
    const secId = parseNodeId(sectionLink);
    if (secId) {
      const section = await figma.getNodeByIdAsync(secId);
      if (section) {
        result.sectionId = section.id;
        const children = section.children || [];
        for (let i = 0; i < children.length; i++) {
          const child = children[i];
          if (child.name === 'Alt Tag') continue;
          const w = Math.round(child.width);
          if (Math.abs(w - 901) > 2 && Math.abs(w - 427) > 2) continue;
          const next = children[i + 1];
          const hasAlt = !!(next && next.name === 'Alt Tag');
          const existing = hasAlt ? (next.children?.find(c => c.type === 'TEXT')?.characters || '') : '';
          result.images.push({ id: child.id, name: child.name, hasAlt, existing: existing.slice(0, 100) });
        }
      }
    }
  }
  return result;
}

// ── IMPORT: Write alt tags from JSON ──────────────────────────
async function importAltTags(items) {
  await figma.loadFontAsync({ family: '72', style: 'Regular' });
  await figma.loadFontAsync({ family: '72', style: 'Bold' });
  let count = 0;

  for (const { id, alt } of items) {
    const node = await figma.getNodeByIdAsync(id);
    if (!node || !node.parent) continue;
    const parent = node.parent;
    const idx = parent.children.indexOf(node);
    const next = parent.children[idx + 1];

    if (next && next.name === 'Alt Tag') {
      // Update existing
      const txt = next.children?.find(c => c.type === 'TEXT');
      if (txt) { await figma.loadFontAsync(txt.fontName); txt.characters = alt; }
    } else {
      // Create new
      const frame = figma.createFrame();
      frame.name = 'Alt Tag';
      frame.layoutMode = 'HORIZONTAL';
      frame.counterAxisAlignItems = 'MIN';
      frame.primaryAxisSizingMode = 'FIXED';
      frame.counterAxisSizingMode = 'AUTO';
      frame.resize(node.width, 40);
      frame.fills = [{ type: 'SOLID', color: { r: 0.961, g: 0.965, b: 0.969 } }];
      frame.paddingTop = 6; frame.paddingBottom = 6;
      frame.paddingLeft = 8; frame.paddingRight = 8;
      frame.itemSpacing = 8;

      // Badge
      const badge = figma.createFrame();
      badge.name = 'Tag';
      badge.layoutMode = 'HORIZONTAL';
      badge.counterAxisSizingMode = 'AUTO';
      badge.primaryAxisSizingMode = 'AUTO';
      badge.paddingTop = 2; badge.paddingBottom = 2;
      badge.paddingLeft = 6; badge.paddingRight = 6;
      badge.cornerRadius = 4;
      badge.fills = [{ type: 'SOLID', color: { r: 0.878, g: 0.925, b: 1.0 } }];
      const badgeTxt = figma.createText();
      badgeTxt.fontName = { family: '72', style: 'Bold' };
      badgeTxt.fontSize = 10;
      badgeTxt.characters = 'Alt Tag';
      badgeTxt.fills = [{ type: 'SOLID', color: { r: 0.0, g: 0.392, b: 0.851 } }];
      badge.appendChild(badgeTxt);
      frame.appendChild(badge);

      // Text
      const txt = figma.createText();
      txt.name = 'Alt tag';
      txt.fontName = { family: '72', style: 'Regular' };
      txt.fontSize = 11;
      txt.characters = alt;
      txt.fills = [{ type: 'SOLID', color: { r: 0.114, g: 0.176, b: 0.239 } }];
      frame.appendChild(txt);
      // FILL must be set AFTER appendChild — parent must be auto-layout first
      txt.layoutGrow = 1;
      txt.layoutSizingHorizontal = 'FILL';
      parent.insertChild(idx + 1, frame);
    }
    count++;
  }
  return { count };
}

// ── RENAME ────────────────────────────────────────────────────
async function renameImages(sectionLink, prefix, version) {
  const secId = parseNodeId(sectionLink);
  if (!secId) throw new Error('Invalid link.');
  const section = await figma.getNodeByIdAsync(secId);
  if (!section) throw new Error('Section not found.');

  const children = section.children || [];
  const renamed = [];
  let globalNum = 0;
  let currentSection = 'General';
  let sectionCount = 0;

  // Walk children in order — TEXT nodes are headings, FRAME nodes are images
  for (const child of children) {
    // Heading: any text node → update current section, never count
    if (child.type === 'TEXT') {
      if (child.characters?.trim()) {
        const raw = child.characters.trim().split('\n')[0];
        currentSection = raw
          .replace(/[^a-zA-Z0-9 ]/g, '')
          .trim()
          .split(/\s+/)
          .map(w => w.charAt(0).toUpperCase() + w.slice(1))
          .join('');
        sectionCount = 0;
      }
      continue; // never count text nodes
    }

    // Only process FRAME / COMPONENT / INSTANCE nodes
    if (child.type !== 'FRAME' && child.type !== 'COMPONENT' && child.type !== 'INSTANCE') continue;

    // Skip Alt Tag frames
    if (child.name === 'Alt Tag') continue;

    const w = Math.round(child.width);

    // Thumbnail: 312px wide → 00_ComponentName_Thumbnail_vXXXX
    if (Math.abs(w - 312) <= 2) {
      const newName = `00_${prefix}_Thumbnail_v${version}`;
      renamed.push({ old: child.name, new: newName });
      child.name = newName;
      continue;
    }

    // Image frames: 901px or 427px wide
    if (Math.abs(w - 901) > 2 && Math.abs(w - 427) > 2) continue;

    globalNum++;
    sectionCount++;
    const gNum = String(globalNum).padStart(2, '0');
    const sNum = String(sectionCount).padStart(2, '0');
    const newName = `${gNum}_${prefix}_${currentSection}_${sNum}_v${version}`;
    renamed.push({ old: child.name, new: newName });
    child.name = newName;
  }

  return { renamed };
}

// ── MESSAGE HANDLER ───────────────────────────────────────────
figma.ui.onmessage = async (msg) => {
  try {
    if (msg.type === 'resize') {
      figma.ui.resize(msg.width, msg.height);
    }
    if (msg.type === 'export-data') {
      const result = await exportData(msg.articleLink, msg.sectionLink);
      figma.ui.postMessage({ type: 'export-result', ...result });
    }
    if (msg.type === 'import-alt-tags') {
      const result = await importAltTags(msg.items);
      figma.ui.postMessage({ type: 'import-result', ...result });
    }
    if (msg.type === 'rename-images') {
      const result = await renameImages(msg.sectionLink, msg.prefix, msg.version);
      figma.ui.postMessage({ type: 'rename-result', ...result });
    }
    if (msg.type === 'get-selection') {
      const sel = figma.currentPage.selection;
      if (sel.length === 1) figma.ui.postMessage({ type: 'selection', nodeId: sel[0].id, name: sel[0].name });
      else figma.ui.postMessage({ type: 'selection', nodeId: null });
    }
  } catch(err) {
    figma.ui.postMessage({ type: 'error', message: err.message });
  }
};
